|  Locale  |  Lines  | % Done|
|----------|---------|-------|
| Template |      12 |       |
| ru       |   12/12 |  100% |
